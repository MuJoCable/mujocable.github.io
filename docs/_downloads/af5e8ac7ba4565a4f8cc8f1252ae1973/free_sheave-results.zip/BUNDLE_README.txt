MuJoCable documentation resource bundle
Source: https://github.com/MuJoCable/mujoco-cable-dynamics/tree/fccad906154cddb8e05227924a6c72efc80e3387
Extract into a separate folder; preserve relative model/asset paths.
Use a matching, compiled MuJoCable plugin and the repository viewer.
The model bundle is not a Python/MuJoCo runtime.
